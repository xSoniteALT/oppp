TOKEN = ""

MAILSLURP_API_KEY=""


#Dont Fill These In
LastUsedEmail=""
LastUserName=""
LastRecoveryCode=""
